<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<!-- Datatables Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="n-0 font-weight-bold text-primary">EDIT COURSES</h6>

    </div>
    <div class="card-body">

        <?php 
      


        if(isset($_POST['course_edit_btn'])){
           $id = $_POST['edit_id'];

           $query = "SELECT * FROM course WHERE CourseID='$id' ";
           $query_run = mysqli_query($connection, $query);

           foreach($query_run as $row){

            ?>

            <form action="code.php" method="POST">
               <input type="hidden" name="course_edit_id" value="<?php echo $row['CourseID'] ?>">



               <div class="form-group">
                <label>Course Name </label>
                <input type="text" name="edit_CourseName" value="<?php echo $row['Course_Name'] ?>" class="form-control" placeholder="Enter Course Name">
            </div>
          


            <a href="Course.php" class="btn btn-danger"> CANCEL </a>
            <button type="submit" name="course_updatebtn" class="btn btn-primary"> Update </button>

        </form>

        <?php 
    }
}

?>


</div>
</div>
</div>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>