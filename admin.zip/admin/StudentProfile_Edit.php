<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<!-- Datatables Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="n-0 font-weight-bold text-primary">EDIT STUDENT PROFILE</h6>

    </div>
    <div class="card-body">

        <?php 
      


        if(isset($_POST['StudentProfile_edit_btn'])){
           $id = $_POST['edit_id'];

           $query = "SELECT * FROM student WHERE StudentID='$id' ";
           $query_run = mysqli_query($connection, $query);

           foreach($query_run as $row){

            ?>

            <form action="code.php" method="POST">
               <input type="hidden" name="student_edit_id" value="<?php echo $row['StudentID'] ?>">



               <div class="form-group">
                <label> Name </label>
                <input type="text" name="edit_Sname" value="<?php echo $row['Student_Name'] ?>" class="form-control" placeholder="Enter Student Name">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="edit_Semail" value="<?php echo $row['Student_Email'] ?>" class="form-control" placeholder="Enter Teacher Email">
                 <small class="error_email" style="color: red;"></small>
               
            </div>
             <div class="form-group">
                <label> Age </label>
                <input type="number" name="edit_Sage" value="<?php echo $row['Student_Age'] ?>" class="form-control" placeholder="Enter Student Age">
            </div>
             <div class="form-group">
                <label> Grade </label>
                <input type="text" name="edit_Sgrade" value="<?php echo $row['Student_Grade'] ?>" class="form-control" placeholder="Enter Student Grade">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="text" name="edit_Spassword" value="<?php echo $row['Student_Password'] ?>" class="form-control" placeholder="Enter Student Password">
            </div>
             <div class="form-group">
                <label> Contact </label>
                <input type="number" name="edit_Scontact" value="<?php echo $row['Student_Contact'] ?>" class="form-control" placeholder="Enter Contact Number">
            </div>
            <div class="form-group">
                <label>Profile Photo</label>
                <input type="text" name="edit_S_profilePhoto" value="<?php echo $row['Student_profilePhoto'] ?>" class="form-control" placeholder="Enter Profile Photo">
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="Student_Status" class="form-control">
                <option value="Approved"> Approved </option>
                <option value="Unapproved"> Unapproved </option>
                </select>
            </div>




            <a href="Student_Profile.php" class="btn btn-danger"> CANCEL </a>
            <button type="submit" name="StudentProfile_updatebtn" class="btn btn-primary"> Update </button>

        </form>

        <?php 
    }
}

?>


</div>
</div>
</div>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>