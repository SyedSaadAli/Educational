<?php
 include('security.php');
 include('CheckLogin.php');
 include('includes/header.php'); 
 include('includes/navbar.php'); 
?>


<div class="container-fluid">

<!-- Datatables Example -->
<div class="card shadow mb-4">
<div class="card-header py-3">
<h6 class="n-0 font-weight-bold text-primary">Lesson

<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
       Lesson List 
</button>
</h6> </div>
<div class="card-body">

<?php  
   if(isset($_SESSION['success']) && $_SESSION['success'] != '')
   {
    echo '<h2 class="bg-primary"> '.$_SESSION['success'].' </h2>';# text-white
    unset($_SESSION['success']);
   }
    if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
   {
      echo '<h2 class="big-danger"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
   }
?>

     <div class="table-responsive">

    <?php
                $query = "SELECT * FROM lesson";
                $query_run = mysqli_query($connection, $query);
            ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th> ID </th>
                            <th>Lesson Name </th>
                            <th>Course Name </th>
                            <th>EDIT</th>
                            <th>DELETE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if(mysqli_num_rows($query_run) > 0)        
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                        ?>
                            <tr>
                                <td><?php  echo $row['LessonID']; ?></td>
                                <td><?php  echo $row['Lesson_Name']; ?></td>
                                <td><?php  echo $row['Course_Name']; ?></td>

                                <td>
                                    <form action="Lesson_Edit.php" method="post">
                                        <input type="hidden" name="edit_id" value="<?php echo $row['LessonID']; ?>">
                                        <button type="submit" name="Lesson_edit_btn" class="btn btn-success"> EDIT</button>
                                    </form>
                                </td>
                                <td>
                                    <form action="code.php" method="post">
                                        <input type="hidden" name="delete_id" value="<?php echo $row['LessonID']; ?>">
                                        <button type="submit" name="Lesson_delete_btn" class="btn btn-danger"> DELETE</button>
                                    </form>
                                </td>
                            </tr>
                        <?php
                            } 
                        }
                        else {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>

        </div>
</div>
</div>
</div>
<!-- /.container-fluid -->

<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>