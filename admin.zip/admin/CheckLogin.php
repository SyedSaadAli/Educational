<?php
// if($_SESSION['role'] != "admin")
// {
// 	header('location:../Login_Page.html');
// }
?>