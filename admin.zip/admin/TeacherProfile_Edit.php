<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<!-- Datatables Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="n-0 font-weight-bold text-primary">EDIT TEACHER PROFILE</h6>

    </div>
    <div class="card-body">

        <?php 
      


        if(isset($_POST['TeacherProfile_edit_btn'])){
           $id = $_POST['edit_id'];

           $query = "SELECT * FROM teacher WHERE TeacherID='$id' ";
           $query_run = mysqli_query($connection, $query);

           foreach($query_run as $row){

            ?>

            <form action="code.php" method="POST">
               <input type="hidden" name="teacher_edit_id" value="<?php echo $row['TeacherID'] ?>">



               <div class="form-group">
                <label> Name </label>
                <input type="text" name="edit_Tname" value="<?php echo $row['Teacher_Name'] ?>" class="form-control" placeholder="Enter Teacher Name">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="edit_Temail" value="<?php echo $row['Teacher_Email'] ?>" class="form-control" placeholder="Enter Teacher Email">
                 <small class="error_email" style="color: red;"></small>
               
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="text" name="edit_Tpassword" value="<?php echo $row['Teacher_Password'] ?>" class="form-control" placeholder="Enter Teacher Password">
            </div>
            <div class="form-group">
                <label>Profile Photo</label>
                <input type="text" name="edit_T_profilePhoto" value="<?php echo $row['Teacher_profilePhoto'] ?>" class="form-control" placeholder="Enter Profile Photo">
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="update_status" class="form-control">
                <option value="Approved"> Approved </option>
                <option value="Unapproved"> Unapproved </option>
                </select>
            </div>




            <a href="Teacher_Profile.php" class="btn btn-danger"> CANCEL </a>
            <button type="submit" name="TeacherProfile_updatebtn" class="btn btn-primary"> Update </button>

        </form>

        <?php 
    }
}

?>


</div>
</div>
</div>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>