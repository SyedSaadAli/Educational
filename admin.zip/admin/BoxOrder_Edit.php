<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<!-- Datatables Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="n-0 font-weight-bold text-primary">EDIT BOX ORDERS</h6>

    </div>
    <div class="card-body">

        <?php 
      


        if(isset($_POST['edit_btn'])){
           $id = $_POST['edit_id'];

           $query = "SELECT * FROM boxorders WHERE BoxOrderID='$id' ";
           $query_run = mysqli_query($connection, $query);

           foreach($query_run as $row){

            ?>

            <form action="code.php" method="POST">
               <input type="hidden" name="edit_id" value="<?php echo $row['BoxOrderID'] ?>">



               <div class="form-group">
                <label> Name </label>
                <input type="text" name="edit_name" value="<?php echo $row['BoxOrder_Name'] ?>" class="form-control" placeholder="Enter BoxOrder Name">
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="number" name="edit_price" value="<?php echo $row['BoxOrder_Price'] ?>" class="form-control" placeholder="Enter BoxOrder Price">
                <small class="error_email" style="color: red;"></small>
            </div>
            <div class="form-group">
                <label>Quantity</label>
                <input type="number" name="edit_quantity" value="<?php echo $row['BoxOrder_Quantity'] ?>" class="form-control" placeholder="Enter BoxOrder Quantity">
            </div>
            <div class="form-group">
                <label>Description</label>
                <input type="text" name="edit_description" value="<?php echo $row['BoxOrder_Description'] ?>" class="form-control" placeholder="Enter BoxOrder Description">
            </div>




            <a href="BoxOrder.php" class="btn btn-danger"> CANCEL </a>
            <button type="submit" name="boxOrder_updatebtn" class="btn btn-primary"> Update </button>

        </form>

        <?php 
    }
}

?>


</div>
</div>
</div>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>