<?php 
include('security.php');
include('CheckLogin.php');




if(isset($_POST['StudentProfile_updatebtn']))
{
    $id = $_POST['student_edit_id'];
    $SName = $_POST['edit_Sname'];
    $SEmail = $_POST['edit_Semail'];
    $SAge = $_POST['edit_Sage'];
    $SGrade = $_POST['edit_Sgrade'];
    $SPassword = $_POST['edit_Spassword'];
    $SContact = $_POST['edit_Scontact'];
    $SProfilephoto = $_POST['edit_S_profilePhoto'];
    $SStatus = $_POST['Student_Status'];

   

    $query = "UPDATE student SET Student_Name='$SName',Student_Email='$SEmail',Student_Age='$SAge',Student_Grade='$SGrade',Student_Password='$SPassword',Student_Contact='$SContact',Student_profilePhoto='$SProfilephoto',Student_Status='$SStatus' WHERE StudentID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Student Profile is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Student_Profile.php'); 
    }
    else
    {
        $_SESSION['status'] = "Student Profile is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Student_Profile.php');  
    }
}


  if(isset($_POST['Student_delete_btn']))
        {
            $id = $_POST['delete_id'];

            $query = "DELETE FROM student WHERE StudentID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Student Profile is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: Student_Profile.php'); 
            }
            else
            {
                $_SESSION['status'] = "Student Profile is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: Student_Profile.php'); 
            }    
        }


  if(isset($_POST['Student_approved_btn']))
        {
            $id = $_POST['approved_id'];

           $query = "UPDATE student SET Student_Status='Approved' WHERE StudentID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Student Profile is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: Student_Profile.php'); 
            }
            else
            {
                $_SESSION['status'] = "Student Profile is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: Student_Profile.php'); 
            }    
        }



// ----------------------------------------------------------------------------------------------------------






if(isset($_POST['TeacherProfile_updatebtn']))
{
    $id = $_POST['teacher_edit_id'];
    $TName = $_POST['edit_Tname'];
    $TEmail = $_POST['edit_Temail'];
    $TPassword = $_POST['edit_Tpassword'];
    $TProfilephoto = $_POST['edit_T_profilePhoto'];
    $TStatus = $_POST['update_status'];

   

    $query = "UPDATE teacher SET Teacher_Name='$TName',Teacher_Email='$TEmail',Teacher_Password='$TPassword',Teacher_profilePhoto='$TProfilephoto',Teacher_Request='$TStatus' WHERE TeacherID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Teacher Profile is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Teacher_Profile.php'); 
    }
    else
    {
        $_SESSION['status'] = "Teacher Profile is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Teacher_Profile.php');  
    }
}


  if(isset($_POST['Teacher_delete_btn']))
        {
            $id = $_POST['delete_id'];

            $query = "DELETE FROM teacher WHERE TeacherID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Teacher Profile is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: Teacher_Profile.php'); 
            }
            else
            {
                $_SESSION['status'] = "Teacher Profile is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: Teacher_Profile.php'); 
            }    
        }


  if(isset($_POST['Teacher_approved_btn']))
        {
            $id = $_POST['approved_id'];

           $query = "UPDATE teacher SET Teacher_Request='Approved' WHERE TeacherID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Teacher Profile is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: Teacher_Profile.php'); 
            }
            else
            {
                $_SESSION['status'] = "Teacher Profile is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: Teacher_Profile.php'); 
            }    
        }


// ----------------------------------------------------------------------------------------------------------




if(isset($_POST['course_updatebtn']))
{
    $id = $_POST['course_edit_id'];
    $courseName = $_POST['edit_CourseName'];
   

    $query = "UPDATE course SET Course_Name='$courseName' WHERE CourseID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Course is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Course.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Course is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Course.php');  
    }
}


  if(isset($_POST['course_delete_btn']))
        {
            $id = $_POST['delete_id'];

            $query = "DELETE FROM course WHERE CourseID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Your Course is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: Course.php'); 
            }
            else
            {
                $_SESSION['status'] = "Your Course is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: Course.php'); 
            }    
        }



// ----------------------------------------------------------------------------------------------------------




if(isset($_POST['Lesson_updatebtn']))
{
    $id = $_POST['Lesson_edit_id'];
    $lessonName = $_POST['edit_lesson_name'];
    $courseName = $_POST['edit_course_name'];
   

    $query = "UPDATE lesson SET Lesson_Name='$lessonName', Course_Name='$courseName' WHERE LessonID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Lesson is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Lesson.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Lesson is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Lesson.php');  
    }
}


  if(isset($_POST['Lesson_delete_btn']))
        {
            $id = $_POST['delete_id'];

            $query = "DELETE FROM lesson WHERE LessonID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Your Lesson is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: Lesson.php'); 
            }
            else
            {
                $_SESSION['status'] = "Your Lesson is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: Lesson.php'); 
            }    
        }




// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['boxOrder_updatebtn']))
{
    $id = $_POST['edit_id'];
    $name = $_POST['edit_name'];
    $price = $_POST['edit_price'];
    $quantity = $_POST['edit_quantity'];
	$description = $_POST['edit_description'];

    $query = "UPDATE boxorders SET BoxOrder_Name='$name', BoxOrder_Price='$price', BoxOrder_Quantity='$quantity' , BoxOrder_Description='$description' WHERE BoxOrderID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: BoxOrder.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: BoxOrder.php');  
    }
}


  if(isset($_POST['boxOrder_delete_btn']))
        {
            $id = $_POST['delete_id'];

            $query = "DELETE FROM boxorders WHERE BoxOrderID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Your Data is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: BoxOrder.php'); 
            }
            else
            {
                $_SESSION['status'] = "Your Data is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: BoxOrder.php'); 
            }    
        }





// ----------------------------------------------------------------------------------------------------------






?>