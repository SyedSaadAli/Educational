<?php 
include('security.php');






// ----------------------------------------------------------------------------------------------------------




if(isset($_POST['Lesson_updatebtn']))
{
    $id = $_POST['Lesson_edit_id'];
    $lessonName = $_POST['edit_lesson_name'];
    $courseName = $_POST['edit_course_name'];
   

    $query = "UPDATE lesson SET Lesson_Name='$lessonName', Course_Name='$courseName' WHERE LessonID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Lesson is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Lesson.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Lesson is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Lesson.php');  
    }
}


  if(isset($_POST['Lesson_delete_btn']))
        {
            $id = $_POST['delete_id'];

            $query = "DELETE FROM lesson WHERE LessonID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Your Lesson is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: Lesson.php'); 
            }
            else
            {
                $_SESSION['status'] = "Your Lesson is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: Lesson.php'); 
            }    
        }




// ----------------------------------------------------------------------------------------------------------




if(isset($_POST['Feedback_updatebtn']))
{
    $id = $_POST['Feedback_edit_id'];
    $FeedbackTeacherName = $_POST['edit_teacher_name'];
    $Feedback = $_POST['edit_comment'];
    $Student = $_POST['edit_student_name'];

   

    $query = "UPDATE feedback SET Teacher_Name='$FeedbackTeacherName', Comment='$Feedback', Student_Name='$Student' WHERE FeedbackID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Feedback is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Feedback.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Feedback is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Feedback.php');  
    }
}


  if(isset($_POST['Feedback_delete_btn']))
        {
            $id = $_POST['delete_id'];

            $query = "DELETE FROM feedback WHERE FeedbackID='$id' ";
            $query_run = mysqli_query($connection, $query);

            if($query_run)
            {
                $_SESSION['status'] = "Your Feedback is Deleted";
                $_SESSION['status_code'] = "success";
                header('Location: Feedback.php'); 
            }
            else
            {
                $_SESSION['status'] = "Your Feedback is NOT DELETED";       
                $_SESSION['status_code'] = "error";
                header('Location: Feedback.php'); 
            }    
        }





?>