<?php

include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<!-- Datatables Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="n-0 font-weight-bold text-primary">EDIT Lessons</h6>

    </div>
    <div class="card-body">

        <?php 
      


        if(isset($_POST['Lesson_edit_btn'])){
           $id = $_POST['edit_id'];

           $query = "SELECT * FROM lesson WHERE LessonID='$id' ";
           $query_run = mysqli_query($connection, $query);

           foreach($query_run as $row){

            ?>

            <form action="code.php" method="POST">
               <input type="hidden" name="Lesson_edit_id" value="<?php echo $row['LessonID'] ?>">



               <div class="form-group">
                <label>Lesson Name </label>
                <input type="text" name="edit_lesson_name" value="<?php echo $row['Lesson_Name'] ?>" class="form-control" placeholder="Enter Lesson Name">
            </div>
            <div class="form-group">
                <label>Course Name</label>
                <input type="text" name="edit_course_name" value="<?php echo $row['Course_Name'] ?>" class="form-control" placeholder="Enter Course Name">
             
            </div>
           




            <a href="Lesson.php" class="btn btn-danger"> CANCEL </a>
            <button type="submit" name="Lesson_updatebtn" class="btn btn-primary"> Update </button>

        </form>

        <?php 
    }
}

?>


</div>
</div>
</div>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>