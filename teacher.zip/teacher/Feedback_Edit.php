<?php

include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<!-- Datatables Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="n-0 font-weight-bold text-primary">EDIT Feedback</h6>

    </div>
    <div class="card-body">

        <?php 
      


        if(isset($_POST['Feedback_edit_btn'])){
           $id = $_POST['edit_id'];

           $query = "SELECT * FROM feedback WHERE FeedbackID='$id' ";
           $query_run = mysqli_query($connection, $query);

           foreach($query_run as $row){

            ?>

            <form action="code.php" method="POST">
               <input type="hidden" name="Feedback_edit_id" value="<?php echo $row['FeedbackID'] ?>">



               <div class="form-group">
                <label>Teacher Name</label>
                <input type="text" name="edit_teacher_name" value="<?php echo $row['Teacher_Name'] ?>" class="form-control" placeholder="Enter Teacher Name">
            </div>
            <div class="form-group">
                <label>Comment</label>
                <input type="text" name="edit_comment" value="<?php echo $row['Comment'] ?>" class="form-control" placeholder="Enter Comments">
            </div>
           <div class="form-group">
                <label>Student Name</label>
                <input  type="text" name="edit_student_name" disabled="True" value="<?php echo $row['Student_Name'] ?>" class="form-control" >
            </div>
          
           
           




            <a href="Feedback.php" class="btn btn-danger"> CANCEL </a>
            <button type="submit" name="Feedback_updatebtn" class="btn btn-primary"> Update </button>

        </form>

        <?php 
    }
}

?>


</div>
</div>
</div>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>